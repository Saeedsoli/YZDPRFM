# مرجع API — عطر یزد

۶۶ مسیر ثابت و ۱۱ مسیر پارامتری، در سه سطح دسترسی. همه پاسخ‌ها
JSON با `charset=utf-8` و در صورت پشتیبانی مرورگر، فشرده با gzip.

> **این سند زنده است.** `node scripts/audit_docs.js` بررسی می‌کند
> هر مسیر موجود در کد اینجا مستند شده باشد — و برعکس، مسیری که
> اینجا هست ولی در کد نیست گزارش می‌شود.

---

## احراز هویت

| سطح | روش | مدت |
|---|---|---|
| عمومی | ندارد | — |
| مشتری | هدر `X-Customer-Token` یا کوکی `yazd_customer` | ۳۰ روز |
| مدیر | هدر `Authorization: Bearer` یا کوکی `yazd_admin` | ۸ ساعت |

نشست‌ها در جدول `sessions` ذخیره می‌شوند و با ری‌استارت سرور
از بین نمی‌روند.

---

## کدهای پاسخ

| کد | معنی |
|---|---|
| `200` `201` | موفق |
| `400` | ورودی نامعتبر (در لاگ ثبت نمی‌شود) |
| `401` | نیازمند ورود |
| `403` | دسترسی به منبع دیگری |
| `404` | یافت نشد |
| `409` | تکراری |
| `429` | عبور از محدودیت نرخ |
| `500` | خطای سرور (در لاگ ثبت می‌شود) |

قالب خطا:
```json
{ "error": "پیام فارسی قابل نمایش به کاربر" }
```

---

## محدودیت نرخ

| عملیات | حد | پنجره | مسدودی |
|---|---|---|---|
| ورود مدیر | ۶ | ۱۰ دقیقه | ۱۵ دقیقه |
| کد ورود (IP) | ۱۲ | ۱ ساعت | ۳۰ دقیقه |
| کد ورود (شماره) | ۵ | ۱ ساعت | ۱ ساعت |
| ثبت سفارش | ۱۰ | ۱۰ دقیقه | ۱۰ دقیقه |
| ثبت نظر | ۵ | ۲۴ ساعت | — |

---

# محصولات

### `GET /api/products`

| پارامتر | پیش‌فرض | توضیح |
|---|---|---|
| `q` | — | جستجو (تا ۵ واژه، یکسان‌سازی فارسی) |
| `family` | — | `woody` `floral` `citrus` … |
| `gender` | — | `MEN` `WOMEN` `UNISEX` |
| `brand` | — | نام فارسی یا لاتین |
| `page` | ۱ | شماره صفحه |
| `limit` | ۲۴ | حداکثر ۶۰ |
| `sort` | — | `price_asc` `price_desc` `name` `brand` |
| `full` | `0` | `1` = شامل همه متغیرها |

بدون `full=1` پاسخ سبک است (کارت محصول به متغیرها نیاز ندارد) —
۱۲ کیلوبایت به‌جای ۸۰.

```json
{
  "total": 2111, "page": 1, "limit": 24, "totalPages": 88,
  "products": [{
    "id": "YZD-PROD-0029", "slug": "creed-aventus",
    "name_fa": "اونتوس", "name_en": "CREED - Aventus",
    "brand_fa": "کرِید", "gender": "MEN",
    "family_fa": "مدیترانه‌ای میوه‌ای",
    "notes": { "top": ["آناناس", "ترنج", "سیب"] },
    "image_url": "/images/products/brand-creed.jpg",
    "min_price": 196000, "in_stock": true, "variant_count": 7
  }]
}
```

**جستجو:** `کرید` = `کرِید` = `كريد` → هر سه یک نتیجه.
اعراب حذف و حروف عربی یکسان می‌شوند.

**مرتب‌سازی:** مقدار `sort` از یک **فهرست سفید** رد می‌شود و هرگز
مستقیم وارد SQL نمی‌گردد. مقدار ناشناخته → ترتیب پیش‌فرض.
قیمت در جدول `products` نیست، پس `price_asc` / `price_desc` روی
`MIN(price_toman)` متغیرها زیرپرس‌وجو می‌زنند.

### `GET /api/products/:slug`

محصول کامل با همه متغیرها.

### `GET /api/brands` · `GET /api/families`

فهرست با تعداد محصول هر گروه.

---

# کوییز

### `POST /api/quiz`

```json
{ "answers": {
  "gender": "MEN", "temperature": "گرم",
  "season": "پاییز و زمستان", "occasion": "رسمی",
  "family": "شرقی", "budget": "mid"
}}
```

هر پاسخ می‌تواند `ANY` باشد. امتیازدهی وزنی: جنسیت و خانواده ۳،
فصل و مناسبت و طبع ۲. حداکثر ۲ محصول از هر برند.

منطق امتیازدهی در `src/taste.js` است تا `/api/taste/suggest` هم از
همان فرمول استفاده کند.

**پاسخ:**
```json
{ "total": 6, "results": [...], "total_products": 2111,
  "profile": { "gender": "MEN", "family": "شرقی" },
  "profile_saved": true, "budget_relaxed": false }
```

اگر کاربر وارد شده باشد، پاسخ‌ها به‌عنوان پروفایل بویایی در جدول
`customers` ذخیره می‌شوند (`profile_saved`). برای مهمان، مرورگر
خودش در `localStorage` نگه می‌دارد.

### `GET /api/notes`

فهرست نُت‌های بویایی با شمار محصول — برای نوار فیلتر.

| پارامتر | پیش‌فرض | کار |
|---|---|---|
| `position` | همه | `top` · `middle` · `base` · `accord` |
| `min` | ۱۲ | حداقل شمار محصول برای نمایش |
| `limit` | ۶۰ | سقف تعداد |

```json
{ "notes": [ { "note_key": "وانیل", "note": "وانیل", "count": 916 } ],
  "position": null }
```

`min` جلوی شلوغی را می‌گیرد: نُتی که یک عطر دارد در فهرست فیلتر
مزاحم است، نه مفید. **شمار اعلام‌شده تضمین می‌شود** — چیپی که
می‌گوید ۹۱۶، دقیقاً ۹۱۶ نتیجه می‌دهد و هرگز بن‌بست نیست.

### فیلتر نُت در `/api/products`

```
/api/products?note=وانیل
/api/products?note=وانیل,ترنج        ← هر دو (AND)
/api/products?note=وانیل&gender=WOMEN
```

چند نُت با **AND** ترکیب می‌شوند نه OR: «وانیل و ترنج» یعنی
محصولی که هر دو را دارد. سقف چهار نُت. تطبیق دقیق است، پس نام نُت
باید همان چیزی باشد که `/api/notes` می‌دهد.

---

# پروفایل بویایی

### `POST /api/taste/suggest`

پیشنهاد بر پایه پروفایل. دو راه ورودی:

- **کاربر واردشده** — پروفایل از دیتابیس خوانده می‌شود (`source: account`)
- **مهمان** — پروفایل در بدنه درخواست می‌آید (`source: guest`)

```json
{ "answers": { "gender": "WOMEN", "family": "گلی" } }
```

```json
{ "items": [...], "profile": {...},
  "summary": ["زنانه", "گلی"],
  "budget_relaxed": false, "source": "guest" }
```

`budget_relaxed` یعنی در محدوده بودجه گزینه کافی نبود و بازه بازتر
شد — رابط این را صادقانه به کاربر می‌گوید.

پروفایل با کمتر از دو معیار «بی‌معنا» شمرده می‌شود و پیشنهادی
تولید نمی‌کند.

### `GET /api/taste/profile`

پروفایل ذخیره‌شده کاربر واردشده.

```json
{ "authenticated": true, "profile": {...},
  "summary": ["زنانه", "گلی"], "updated_at": "2026-08-01 12:00:00" }
```

### `DELETE /api/taste/profile`

حذف پروفایل — کاربر باید بتواند فراموش شود. نیازمند ورود (۴۰۱).

---

# سبد و سفارش

### `POST /api/cart/sync`

وضعیت زنده چند SKU — برای همگام‌سازی سبدی که در `localStorage`
مرورگر مانده است.

```json
{ "skus": ["YZD-0029-EDP-050", "YZD-0001-SMP-003"] }
```

```json
{
  "variants": [{
    "sku": "YZD-0029-EDP-050",
    "price": 4700000, "stock": 12,
    "slug": "creed-aventus",
    "image_url": "/images/products/brand-creed.jpg",
    "name": "کرِید — اونتوس — ادو پرفیوم دست‌ساز ۵۰ میل"
  }]
}
```

سبد ممکن است روزها دست‌نخورده بماند و در این فاصله قیمت عوض شود یا
کالا تمام شود. SKU ناموجود در پاسخ نمی‌آید → سمت کاربر از سبد حذف
می‌شود. حداکثر ۳۰ SKU در هر درخواست.

### `GET /api/contact-info`

اطلاعات تماس عمومی برای صفحه «تماس با ما».

```json
{
  "shop_name": "عطر یزد", "shop_name_en": "Yazd Perfume",
  "phone": "03536248000",
  "address": "یزد، خیابان کاشانی، مجتمع تجاری نگین، طبقه دوم",
  "postal_code": "8916945781", "enamad_code": null
}
```

کد اقتصادی و شناسه ملی عمداً برگردانده **نمی‌شوند** — آن‌ها فقط روی
فاکتور رسمی معنا دارند، نه در یک API باز.

### `POST /api/cart/calculate`

```json
{
  "items": [{ "sku": "YZD-0029-EDP-050", "quantity": 1 }],
  "coupon_code": "WELCOME10",
  "province": "یزد", "city": "یزد"
}
```

**قیمت همیشه از دیتابیس خوانده می‌شود.** اگر کاربر
`price_toman` بفرستد، نادیده گرفته می‌شود.

اعتبارسنجی: تعداد باید عدد صحیح ۱ تا ۵۰ باشد، حداکثر ۳۰ قلم.

### `POST /api/orders`

**رزرو ظرفیت کد تخفیف.** اگر سفارش کد تخفیف داشته باشد، ظرفیت
همین‌جا رزرو می‌شود — نه هنگام پرداخت. اگر ظرفیت در همان لحظه پر
شود پاسخ `409` است.

ظرفیت رزروشده هنگام لغو، انقضا یا خطای درگاه آزاد می‌گردد.


```json
{
  "customer_name": "نام کامل",
  "mobile": "09123456789",
  "province": "یزد", "city": "یزد",
  "address": "نشانی کامل", "postal_code": "8916945781",
  "coupon_code": "WELCOME10",
  "items": [{ "sku": "...", "quantity": 1 }]
}
```

موجودی در همان تراکنش کم می‌شود. اگر درگاه خطا دهد، بازمی‌گردد.
سفارش پرداخت‌نشده پس از ۳۰ دقیقه `EXPIRED` و موجودی آزاد می‌شود.

پاسخ شامل `payment_url` است.

### `POST /api/payment/verify`

**idempotent است.** درگاه بانکی گاهی callback را چند بار می‌فرستد؛
تنها اولین فراخوانی اثر دارد.

| وضعیت سفارش هنگام فراخوانی | پاسخ |
|---|---|
| `PENDING` | پردازش می‌شود → `PAID` یا `CANCELLED` |
| `PAID` | `200` «قبلاً پرداخت شده» — بدون تغییر |
| `VERIFYING` | `409` «هم‌اکنون در حال پردازش است» |
| سایر | `409` با نام وضعیت |

`VERIFYING` وضعیت گذراست: پیش از گفت‌وگو با درگاه گرفته می‌شود و در
همان درخواست به `PAID` یا `CANCELLED` می‌رود. کاربر آن را نمی‌بیند.

بدون این قفل، ده callback هم‌زمان موجودی را ده بار آزاد می‌کردند.


```json
{ "order_id": "YZD-...", "result": "success" }
```

در حالت زرین‌پال `authority` لازم است. تأیید دوباره مسدود می‌شود.

### `GET /payment/callback`

بازگشت از درگاه واقعی. تأیید و هدایت به `/payment/result`.

### `GET /api/orders/track?mobile=&order_id=`

پیگیری بدون نیاز به ورود.

### `GET /api/orders/:id/history`

تاریخچه وضعیت. مدیر یا صاحب سفارش.

---

# ورود مشتری

### `POST /api/auth/request-code`

```json
{ "mobile": "09123456789" }
```

فرمت‌های پذیرفته: `۰۹۱۲…` `+98912…` `912…` `0912 345 6789`

کد ۵ رقمی، اعتبار ۲ دقیقه، فاصله ارسال مجدد ۶۰ ثانیه،
حداکثر ۵ تلاش نادرست.

در حالت `SMS_PROVIDER=console` کد در لاگ سرور چاپ می‌شود.

### `POST /api/auth/verify-code` · `GET /api/auth/me` · `GET /api/auth/orders` · `POST /api/auth/logout`

---

# علاقه‌مندی و نظرات

### `GET|POST /api/wishlist` — نیازمند ورود

`POST` رفتار تغییر وضعیت دارد: اگر موجود باشد حذف می‌شود.

### `GET /api/reviews/:slug`

```json
{
  "summary": { "count": 12, "avg": 4.3, "longevity": 4.6,
               "sillage": 3.9, "breakdown": { "5": 7, "4": 3 } },
  "reviews": [...],
  "my_review": null,
  "can_review": true,
  "purchased": true
}
```

فقط نظرات تأییدشده. اگر شماره در سفارش پرداخت‌شده باشد،
نشان «خرید تأییدشده» می‌گیرد.

هر نظر `source` دارد: `ONLINE` (خرید آنلاین) یا `INVITED`
(مشتری فروش حضوری با دعوت‌نامه). فرانت برای هر کدام نشان جدا
نشان می‌دهد.

### `POST /api/reviews` — نیازمند ورود

امتیاز ۱ تا ۵، متن حداقل ۱۰ حرف. هر نظر پس از تأیید مدیر منتشر می‌شود.

### `GET /api/review-invite/:token`

دعوت‌نامه نظر برای مشتریان فروش حضوری. **بدون نیاز به ورود** —
خودِ توکن سند هویت است.

```json
{
  "product": { "id": "YZD-0001", "slug": "creed-aventus", "name_fa": "..." },
  "mobile_masked": "0912****11",
  "expires_at": "2026-08-28T…"
}
```

| حالت | پاسخ |
|---|---|
| توکن نامعتبر یا بدشکل | `410` |
| قبلاً استفاده شده | `410` با `used: true` (پیام سپاسگزارانه) |
| منقضی شده | `410` |

### `POST /api/review-invite`

```json
{ "token": "…", "rating": 4, "display_name": "رضا م.",
  "title": "…", "body": "…", "longevity": 4, "sillage": 3 }
```

نظر با `source: 'INVITED'` و `verified: 1` ثبت می‌شود، وضعیت
`PENDING` تا تأیید مدیر. دعوت‌نامه **در همان تراکنش** مصرف
می‌شود — درخواست همزمان با یک توکن فقط یکی می‌گذرد.

### `POST /api/stock-alert`

ثبت شماره برای کالای ناموجود. هنگام افزایش موجودی، پیامک خودکار.

---

# تیکت و مجله

### `POST /api/tickets`

```json
{
  "order_id": "YZD-MS0N4PNV",
  "product_name": "کرِید — اونتوس",
  "volume_ml": 30,
  "used_under_2ml": true,
  "description": "رایحه با توضیحات سایت مطابقت ندارد"
}
```

| بررسی | خطا |
|---|---|
| حجم > ۱۰ میلی‌لیتر | `400` تنها حجم‌های بالای ۱۰ میلی‌لیتر |
| `used_under_2ml` صحیح | `400` شرط مصرف کمتر از ۲ میلی‌لیتر |
| توضیح ≥ ۱۰ حرف | `400` دلیل مرجوعی را توضیح دهید |
| سفارش وجود دارد | `404` سفارشی با این شماره پیدا نشد |
| وضعیت `SHIPPED` یا `DELIVERED` | `400` هنوز ارسال نشده |
| تیکت باز تکراری ندارد | `409` تیکت باز TKT-… وجود دارد |

پاسخ حداکثر ۲۴ ساعت. اگر کاربر وارد شده باشد شماره‌اش از نشست
برداشته می‌شود، وگرنه از خود سفارش.

### `GET /api/articles?category=` · `GET /api/articles/:slug`

دسته‌ها: `guide` `notes` `video`

---

# مدیریت

همه نیازمند توکن مدیر.

## نشست
`POST /api/admin/login` · `POST /api/admin/logout` · `GET /api/admin/me`

## سفارش
```
GET /api/orders?q=&status=&page=&limit=
PUT /api/orders/:id/status
```

جستجو در شناسه، نام، موبایل، کد رهگیری و شهر.

چرخه مجاز:
```
PENDING → PAID → PROCESSING → SHIPPED → DELIVERED
                                     ↘ RETURNED
```

هنگام `SHIPPED` می‌توان `tracking_code` و `carrier` داد.
`CANCELLED` و `RETURNED` موجودی را برمی‌گردانند.
هر تغییر پیامک خودکار دارد.

## محصول
```
PUT /api/admin/variants/:sku      { price_toman, stock }
PUT /api/admin/products/:slug     { price_change_percent } یا { set_all_stock }
GET /api/admin/low-stock?threshold=10
```

اگر موجودی از صفر بالا برود، به همه منتظران پیامک می‌رود.

## کوپن
```
GET|POST /api/admin/coupons
PUT|DELETE /api/admin/coupons/:code
```

سه نوع: `PERCENT` (با سقف) · `FIXED` · `FREE_SHIPPING`

## نظرات
```
GET /api/admin/reviews?status=PENDING
PUT|DELETE /api/admin/reviews/:id
```

## بررسی آمادگی افتتاح
```
GET  /api/admin/readiness            ← settings.view
GET  /api/admin/readiness?deep=1     ← تماس واقعی با زرین‌پال و پیامیتو
POST /api/admin/readiness/test-sms   ← settings.edit · حداکثر ۵ بار در ساعت
```

هفت مورد سنجیده می‌شود: اطلاعات حقوقی، رمز مدیر، نماد اعتماد،
موجودی، دیسک پایدار، درگاه پرداخت، سرویس پیامک.

**هیچ کلیدی برنگردانده نمی‌شود** — فقط `key_set` و چهار نویسه
آخر با ماسک (`••••7890`). با `test_readiness.js` تضمین شده.

`deep=1` تراکنشی ثبت نمی‌کند و پیامکی نمی‌فرستد: درخواست پرداخت
۱۰۰۰ تومانی که هیچ‌کس رویش نمی‌رود، و پرسش اعتبار حساب که رایگان
است.

## دعوت‌نامه نظر — مشتریان فروش حضوری
```
GET    /api/admin/review-invites          ← reviews.view
POST   /api/admin/review-invites          ← reviews.invite
DELETE /api/admin/review-invites/:id      ← reviews.invite
```

ورودی ساخت: `{ product, mobile, note? }`
خروجی: `{ token, url, expires_at, sms_text }` — متن پیامک آماده
است تا مدیر چیزی تایپ نکند.

| حالت | پاسخ |
|---|---|
| نظر قبلی همین مشتری برای همین محصول | `409` |
| دعوت باز از قبل موجود | `200` با `reused: true` (همان لینک) |
| حذف دعوت **استفاده‌شده** | `409` — سابقه حفظ می‌شود |

اعتبار: **۳۰ روز** · یک‌بارمصرف · توکن ۳۲ نویسه تصادفی

## گزارش
```
GET /api/admin/reports?days=30
```

شامل: خلاصه با درصد رشد، فروش روزانه، پرفروش‌ترین، تفکیک
برند و نوع و استان، مشتریان وفادار، عملکرد کوپن، ارزش انبار.

## فاکتور
```
GET /api/orders/:id/invoice
```

مدیر یا صاحب سفارش. شماره فاکتور فقط یک‌بار صادر می‌شود.
`totals` تنها چهار عدد دارد: `subtotal`، `discount`، `shipping`،
`grand_total`. هیچ مبلغ اضافه‌ای محاسبه نمی‌شود.

## سیستم
```
GET|POST /api/admin/settings
GET /api/admin/logs?level=ERROR
POST /api/admin/maintenance
POST /api/admin/reindex
GET /api/admin/backup
GET /api/admin/backups
GET /api/admin/export/csv
```

### `POST /api/admin/reindex`

بازسازی ایندکس جستجو و ایندکس نُت. مجوز `system.maintenance`.

```json
{ "message": "ایندکس بازسازی شد — 2111 محصول، 22372 نسبت نُت.",
  "products": 2111, "note_rows": 22372, "ms": 340 }
```

هر دو ایندکس از ستون‌های محصول ساخته می‌شوند و فقط هنگام راه‌اندازی
سرور به‌روز می‌شوند. اگر داده محصول از بیرون عوض شود (اسکریپت،
بازیابی پشتیبان، ویرایش مستقیم دیتابیس)، ایندکس کهنه می‌ماند و
**بی‌صدا** نتیجه غلط می‌دهد — جستجو محصول تازه را پیدا نمی‌کند و
فیلتر نُت شمار اشتباه نشان می‌دهد.

### رسانه مقالات

```
GET    /api/admin/media          فهرست تصاویر (آپلودشده + موجود سایت)
POST   /api/admin/media          آپلود تصویر تازه
DELETE /api/admin/media/:name    حذف تصویر آپلودشده
```

مجوز: `content.write` — و برای حذف `content.delete`.

**آپلود** بدنه باینری خام می‌گیرد، نه `multipart`. نام اصلی فایل
در سرآیند `X-File-Name` با `encodeURIComponent` می‌آید.

```bash
curl -X POST https://yazdperfume.ir/api/admin/media \
  -H "Authorization: Bearer TOKEN" \
  -H "Content-Type: image/jpeg" \
  -H "X-File-Name: photo.jpg" \
  --data-binary @photo.jpg
```

پاسخ موفق:

```json
{ "message": "تصویر آپلود شد.", "name": "photo-msh8gt-a1b2c3.jpg",
  "url": "/images/journal/photo-msh8gt-a1b2c3.jpg",
  "size": 84213, "format": "jpg" }
```

قالب از **امضای بایتی** فایل تشخیص داده می‌شود نه از پسوند. تنها
JPG، PNG، WebP و GIF پذیرفته می‌شوند؛ SVG عمداً رد می‌شود چون
می‌تواند اسکریپت داشته باشد. سقف پیش‌فرض ۳ مگابایت.

جزئیات در `ARTICLE_MEDIA.md`.

### `GET /api/admin/reports/csv?days=30`

خروجی گزارش فروش برای اکسل. مجوز: `reports.sales`.

شش بلوک در یک فایل، جدا شده با سطر خالی: خلاصه، فروش روزانه،
پرفروش‌ترین محصولات، تفکیک برند، تفکیک استان، کدهای تخفیف.

```
Content-Type: text/csv; charset=utf-8
Content-Disposition: attachment; filename="yazd-report-30d-2026-08-08.csv"
```

فایل با `\uFEFF` شروع می‌شود؛ بدون آن اکسل فارسی را خراب نشان
می‌دهد.

**چرا یک فایل و نه شش:** CSV استاندارد یک جدول است، ولی شش
دانلود جدا یعنی شش بار کلیک. اکسل بلوک‌های جداشده با سطر خالی
را در یک برگه نشان می‌دهد.

نمونه خروجی: `docs/samples/sales-report.csv`

### `GET /api/admin/me/activity?days=7`

کارنامه و **کارت دسترسی** کارمند واردشده.

```json
{ "profile": { "role_name": "انباردار",
               "role_description": "مدیریت موجودی و آماده‌سازی مرسوله…",
               "permission_count": 6, "total_permissions": 34 },
  "access": {
    "granted": [ { "key": "orders", "label": "سفارش‌ها",
                   "items": [ { "key": "orders.view", "label": "…",
                                "hint": "…", "danger": false } ] } ],
    "denied":  [ … ] },
  "summary": {…}, "highlights": […], "actions": […], "recent": […] }
```

`access.denied` عمدی است: کارمند باید بداند چه کارهایی **از او
برنمی‌آید**، نه فقط چه کارهایی می‌تواند. پیش‌تر تنها یک عدد
(`permission_count`) برمی‌گشت و کارمند وقتی به خطای «دسترسی
ندارید» می‌خورد، نمی‌فهمید اشتباه کرده یا سیستم خراب است.

---

# عمومی

### `GET /api/health`

```json
{
  "status": "ok", "products": 2111, "variants": 14777,
  "payment_gateway": "SANDBOX", "payment_live": false,
  "sms_provider": "console", "sessions": 0,
  "pending_orders": 0, "errors_24h": 0, "uptime": 3600
}
```

### `GET /sitemap.xml` · `GET /robots.txt`

۲٬۱۱۴ لینک: صفحات اصلی + ۲٬۱۱۱ محصول + مقالات.
با gzip از ۲۲۷ به ۱۰ کیلوبایت.

---

## صفحات

| مسیر | نیاز |
|---|---|
| `/` `/quiz` `/journal` `/brands` `/track` `/contact` `/terms` `/privacy` | — |
| `/perfume/:slug` `/journal/:slug` | وجود رکورد، وگرنه `404` |
| `/cart` `/checkout` `/login` | — |
| `/account` `/wishlist` | ورود مشتری |
| `/invoice?order=` `/label?order=` | مدیر یا صاحب سفارش |
| `/admin` | رمز |

---

# هویت مشتری

نام کاربری مشتری **شماره موبایل** است. ورود با رمز عبور؛ پیامک
تنها برای بازیابی رمز به کار می‌رود.

### `POST /api/auth/register`
```json
{ "first_name": "مریم", "last_name": "احمدی",
  "mobile": "09131112233", "password": "رمز ۸ نویسه‌ای" }
```
اگر شماره از قبل سفارش داده ولی رمز نداشته باشد، به جای خطا
پیام «برای این شماره رمز بگذارید» می‌آید.

### `POST /api/auth/login`
```json
{ "mobile": "09131112233", "password": "..." }
```
پاسخ: `{ token, customer }`. پیام خطای «حساب نیست» و «رمز غلط»
عمداً یکسان است تا شماره‌های ثبت‌شده لو نروند.

### `POST /api/auth/forgot-password`
```json
{ "mobile": "09131112233" }
```
کد یکبارمصرف پیامک می‌شود. پاسخ برای شماره ثبت‌نشده هم یکسان است.

### `POST /api/auth/reset-password`
```json
{ "mobile": "09131112233", "code": "12345", "password": "رمز تازه" }
```
پس از موفقیت، همه نشست‌های دیگر آن مشتری باطل می‌شوند.

### `GET /api/auth/me` · `GET /api/auth/orders` · `POST /api/auth/logout`
نیازمند هدر `Authorization: Bearer <token>`.

---

# نقش‌ها و کارکنان

نام کاربری کارمند **کد ملی ۱۰ رقمی** است. رمز موقت هنگام ساخت
حساب، شماره موبایل بدون صفر ابتدایی است و با پیامک اطلاع داده
می‌شود.

### `GET /api/admin/roles`
پنج نقش و مجوزهای هرکدام. نیاز: `staff.manage`.

### `GET /api/admin/permissions`
هر ۳۴ مجوز در ۱۰ حوزه.

### `GET|POST /api/admin/staff` · `PUT|DELETE /api/admin/staff/:id`
ساخت، ویرایش و غیرفعال‌سازی کارمند. کارمند نمی‌تواند نقش خودش
را ارتقا دهد یا حساب خودش را حذف کند — ۲۱ بررسی ضد ارتقا در
`test_rbac_escalation.js`.

### `GET /api/admin/whoami` · `GET /api/admin/me`
هویت و مجوزهای کاربر واردشده.

### `GET /api/admin/me/activity` · `PUT /api/admin/me/profile`
کارنامه شخصی و ویرایش پروفایل خود کارمند.

### `POST /api/admin/change-password`
تغییر رمز خودی. اگر `must_change` روشن باشد، تا تغییر رمز
بقیه مسیرها بسته‌اند.

### `GET /api/admin/audit`
سیاهه ممیزی: چه کسی چه کاری کرد. نیاز: `audit.view`.

---

# تحلیل و ویترین

### `POST /api/track`
ثبت رویداد بازدید از سمت مرورگر. بی‌نام؛ شناسه نشست تصادفی است.

### `GET /api/stats`

آمار زنده فروشگاه — **تنها منبع** عددهای کاتالوگ برای همه صفحات.

هیچ صفحه‌ای نباید شمار محصول یا برند را سخت‌کد کند؛ با اضافه شدن
یک عطر همه خودکار به‌روز می‌شوند. در رابط، هر عنصر با
`data-stat="key"` خودکار پر می‌شود.

```json
{
  "products": 2111, "brands": 124, "variants": 14777,
  "in_stock": 1, "made_to_order": 2111, "orderable": 2111,
  "perfumers": 426, "notes": 5008, "countries": 19,
  "families": 8, "articles": 5,
  "year_from": 1533, "year_to": 2024, "centuries": 5
}
```

کش ۶۰ ثانیه سمت سرور و ۵ دقیقه در `sessionStorage` مرورگر.

### `GET /api/showcase`
ویترین خودکار صفحه اصلی: پرفروش‌ها، پرطرفدارها، پرجستجوها.
اگر داده فروش کافی نباشد، به `bestsellers_fallback` می‌افتد.

### `GET /api/admin/analytics?days=30`
قیف خرید، جستجوهای بی‌نتیجه، رفتار مشتری. نیاز: `reports.traffic`.

### `POST /api/admin/analytics/refresh`
ساخت دوباره ویترین به‌صورت دستی.

### `GET /api/admin/notifications`
اعلان‌های پنل: سفارش تازه، موجودی کم، نظر در انتظار، تیکت باز.

---

# سایر

## جشنواره و اعلان

### `GET /api/notice`

نوار اعلان فعال بالای سایت. تک‌پیامی و بدون چرخش.

```json
{ "notice": { "id":1, "text":"جشنواره نوروزی — ۲۰٪ تخفیف",
  "link":"/samples", "link_label":"دیدن", "tone":"gold" } }
```

اگر اعلان فعالی نباشد `{"notice": null}` برمی‌گردد.

> **چرا اسلایدر نیست:** پژوهش‌های Notre Dame، Nielsen و
> Conversionista نشان می‌دهند فقط ~۱٪ کاربران روی اسلایدر کلیک
> می‌کنند و ۸۴٪ همان کلیک روی اسلاید اول است. تصویر ثابت در
> آزمون A/B چهل درصد کلیک گرفت در برابر دو درصد اسلایدر. ضمناً
> چرخش خودکار CLS را خراب می‌کند.

### `GET /api/campaigns`

جشنواره‌های فعال، برای نمایش نشان تخفیف روی کارت محصول.

### `GET|POST /api/admin/campaigns` · `PUT|DELETE /api/admin/campaigns/:id`

مدیریت جشنواره — تخفیف خودکار بدون کد.
نیاز: `coupons.view` / `coupons.create` / `coupons.toggle` / `coupons.delete`.

```json
{ "title":"جشنواره نوروزی", "percent":20, "max_discount":500000,
  "scope_families":"woody,citrus", "scope_brands":"کرید",
  "scope_types":"EDP", "scope_gender":"MEN",
  "starts_at":"2026-03-20", "ends_at":"2026-04-02" }
```

هر دامنه‌ای که خالی بماند یعنی «بدون محدودیت». دامنه‌های
پرشده با **و** ترکیب می‌شوند.

اگر چند جشنواره شامل یک کالا شوند، **بهترین** اعمال می‌شود نه
جمعشان. درصد بیش از ۹۰ رد می‌شود.

### `GET|POST /api/admin/notices` · `PUT|DELETE /api/admin/notices/:id`

مدیریت نوار اعلان. با انتشار اعلان تازه، قبلی خودکار خاموش
می‌شود — دو نوار همزمان فضای بالای صفحه را می‌بلعد.

لینک **فقط داخلی** پذیرفته می‌شود (باید با `/` شروع شود) تا
کسی نتواند بازدیدکننده را به سایت دیگری بفرستد.

---

### `GET /api/coupons/public?code=SAMPLE20`

اطلاعات نمایشی یک کوپن، برای نشان دادن روی صفحات عمومی.
فقط کوپن فعال، منقضی‌نشده و دارای ظرفیت برمی‌گردد؛ وگرنه ۴۰۴.

هیچ رزروی نمی‌کند و `used_count` یا `active` را لو نمی‌دهد —
اعتبارسنجی واقعی موقع تسویه انجام می‌شود.

```json
{ "code":"SAMPLE20", "type":"PERCENT", "value":20,
  "min_subtotal":300000, "max_discount":300000,
  "description":"تخفیف ویژه سمپل‌ها",
  "per_user_once":true, "remaining":200 }
```

### دامنه کوپن (از مرداد ۱۴۰۵)

`POST /api/admin/coupons` این فیلدهای اختیاری را هم می‌پذیرد:

| فیلد | معنی |
|---|---|
| `scope_families` | فقط این خانواده‌های رایحه (CSV یا آرایه) |
| `scope_brands` | فقط این برندها |
| `scope_types` | `SAMPLE` / `EDP` / `HAIR_MIST` / `BODY_SPLASH` |
| `scope_products` | شناسه محصول مشخص |
| `scope_gender` | `MEN` / `WOMEN` / `UNISEX` |
| `starts_at` | پیش از این تاریخ کار نمی‌کند |
| `max_subtotal` | سقف خرید |
| `first_order_only` | فقط اولین خرید مشتری |
| `assigned_mobile` | کد اختصاصی یک شماره |

**نکته امنیتی:** کوپن دامنه‌دار بدون اقلام سبد رد می‌شود.
دادن تخفیفِ دامنه‌دار روی کل سبد ضرر مستقیم مالی است.

**ترتیب محاسبه:** جشنواره → کوپن. کوپن روی مبلغ پس از جشنواره
حساب می‌شود تا مجموع دو تخفیف از خودِ کالا بیشتر نشود.

### `POST /api/coupons/validate`
```json
{ "code": "WELCOME10", "subtotal": 1200000 }
```
اعتبارسنجی کد تخفیف پیش از تسویه.

### `GET /api/essences`
خانه‌های اسانس (لوزی، ایبرشم، ژیوودان، بل/فیرمنیش) و توضیح هرکدام.
